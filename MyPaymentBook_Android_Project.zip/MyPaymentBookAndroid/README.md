# My Payment Book (Android)

A private, offline-first Android wrapper for the My Payment Book ledger. The app stores records in the app's WebView local storage on the Android device. It does not require an account or internet connection.

## Features
- Separate monthly records
- Opening balance for each month
- Automatically calculated current/closing balance
- Money received and money spent totals
- Person/shop/source name, description, amount and date
- Edit and delete transactions
- JSON backup import/export and CSV export
- Android Downloads integration for exports

## Build the APK with Android Studio
1. Install Android Studio (latest stable) on a Windows, macOS or Linux computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `MyPaymentBookAndroid` folder.
4. Allow Android Studio to install the Android SDK and sync Gradle. Use JDK 17 if prompted.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone, open it, and allow installation from that source if Android asks.

For a distributable signed APK, use **Build > Generate Signed Bundle / APK** in Android Studio and follow its signing wizard. Keep the keystore safe.

## Data safety
Records remain on the device. Export the JSON backup regularly. Clearing app storage or uninstalling the app may erase the local ledger. Keep backups outside the phone as well.

## Package details
- Application ID: `com.vii.mypaymentbook`
- Minimum Android: Android 6.0 (API 23)
- Version: 1.0
