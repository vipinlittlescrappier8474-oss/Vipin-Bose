@echo off
REM Run this from the project folder after Android Studio/Gradle has synced the project.
gradlew.bat assembleDebug
pause
